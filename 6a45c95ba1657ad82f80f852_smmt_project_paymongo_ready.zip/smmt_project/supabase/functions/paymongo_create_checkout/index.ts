// Supabase Edge Function: paymongo_create_checkout
// Creates a PayMongo hosted checkout session for VIP membership.
//
// Env required:
// - SUPABASE_URL
// - SUPABASE_ANON_KEY
// - SUPABASE_SERVICE_ROLE_KEY
// - PAYMONGO_SECRET_KEY
// - APP_SUCCESS_URL
// - APP_CANCEL_URL
// Optional:
// - PAYMONGO_PAYMENT_METHOD_TYPES (comma-separated, e.g. "gcash,paymaya,card,qrph")
//
// Note: amount is in centavos (PHP * 100).

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type Plan = "monthly" | "yearly" | "lifetime";

const VIP_PRICES: Record<Plan, number> = {
  monthly: 3,
  yearly: 27,
  lifetime: 70,
};

function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

function json(data: unknown, status = 200, extraHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...extraHeaders,
    },
  });
}

const corsHeaders = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "authorization, x-client-info, apikey, content-type",
  "access-control-allow-methods": "POST, OPTIONS",
};

function toBase64(input: string): string {
  // deno compatible base64
  return btoa(input);
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405, corsHeaders);

  try {
    const SUPABASE_URL = env("SUPABASE_URL");
    const SUPABASE_ANON_KEY = env("SUPABASE_ANON_KEY");
    const SUPABASE_SERVICE_ROLE_KEY = env("SUPABASE_SERVICE_ROLE_KEY");
    const PAYMONGO_SECRET_KEY = env("PAYMONGO_SECRET_KEY");
    const APP_SUCCESS_URL = env("APP_SUCCESS_URL");
    const APP_CANCEL_URL = env("APP_CANCEL_URL");

    const authHeader = req.headers.get("Authorization") || "";
    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) {
      return json({ error: "Unauthorized" }, 401, corsHeaders);
    }
    const user = userData.user;

    const body = await req.json().catch(() => ({}));
    const plan = String(body?.plan || "").toLowerCase() as Plan;
    if (!VIP_PRICES[plan]) return json({ error: "Invalid plan" }, 400, corsHeaders);

    const methodTypesRaw = (Deno.env.get("PAYMONGO_PAYMENT_METHOD_TYPES") || "gcash,paymaya,card,qrph")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    const amount = Math.round(VIP_PRICES[plan] * 100);
    const reference_number = `vip:${user.id}:${plan}:${Date.now()}`;

    const payload = {
      data: {
        attributes: {
          line_items: [
            {
              name: `VIP ${plan}`,
              amount,
              currency: "PHP",
              quantity: 1,
            },
          ],
          payment_method_types: methodTypesRaw,
          success_url: APP_SUCCESS_URL,
          cancel_url: APP_CANCEL_URL,
          reference_number,
        },
      },
    };

    const paymongoResp = await fetch("https://api.paymongo.com/v2/checkout_sessions", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": `Basic ${toBase64(`${PAYMONGO_SECRET_KEY}:`)}`,
      },
      body: JSON.stringify(payload),
    });

    const paymongoJson = await paymongoResp.json().catch(() => ({}));
    if (!paymongoResp.ok) {
      return json({ error: "PayMongo error", details: paymongoJson }, paymongoResp.status, corsHeaders);
    }

    const checkout_session_id = paymongoJson?.data?.id || "";
    const checkout_url = paymongoJson?.data?.attributes?.checkout_url || "";
    if (!checkout_url) return json({ error: "Missing checkout_url from PayMongo" }, 500, corsHeaders);

    // Update profile using service role (bypass RLS)
    const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { error: updErr } = await adminClient
      .from("profiles")
      .update({
        plan,
        payment_status: "pending",
        payment_reference: checkout_session_id ? `${reference_number} | ${checkout_session_id}` : reference_number,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user.id);

    if (updErr) return json({ error: "Failed to update profile", details: updErr }, 500, corsHeaders);

    return json({ checkout_url, checkout_session_id, reference_number }, 200, corsHeaders);
  } catch (e) {
    console.error(e);
    return json({ error: (e && e.message) ? e.message : "Unknown error" }, 500, corsHeaders);
  }
});

