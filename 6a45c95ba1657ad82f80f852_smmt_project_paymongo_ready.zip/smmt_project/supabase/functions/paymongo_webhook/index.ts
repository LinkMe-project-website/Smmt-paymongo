// Supabase Edge Function: paymongo_webhook
// Verifies PayMongo webhook signature and activates VIP membership.
//
// Env required:
// - SUPABASE_URL
// - SUPABASE_SERVICE_ROLE_KEY
// - PAYMONGO_WEBHOOK_SECRET
//
// PayMongo signature verification (t + '.' + rawBody, HMAC-SHA256) reference:
// docs: https://docs.paymongo.com/docs/developer-tools-webhook-setup-management#securing-a-webhook

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type Plan = "monthly" | "yearly" | "lifetime";

function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function parseSignatureHeader(header: string) {
  const parts = header.split(",").map((s) => s.trim()).filter(Boolean);
  const out: Record<string, string> = {};
  for (const p of parts) {
    const idx = p.indexOf("=");
    if (idx === -1) continue;
    const k = p.slice(0, idx).trim();
    const v = p.slice(idx + 1).trim();
    out[k] = v;
  }
  return {
    t: out["t"] || "",
    te: out["te"] || "",
    li: out["li"] || "",
  };
}

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

function addMonths(date: Date, months: number): Date {
  const d = new Date(date.getTime());
  d.setMonth(d.getMonth() + months);
  return d;
}

serve(async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const SUPABASE_URL = env("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = env("SUPABASE_SERVICE_ROLE_KEY");
    const PAYMONGO_WEBHOOK_SECRET = env("PAYMONGO_WEBHOOK_SECRET");

    const rawBody = await req.text();

    const sigHeader = req.headers.get("Paymongo-Signature") || req.headers.get("paymongo-signature") || "";
    if (!sigHeader) return json({ error: "Missing Paymongo-Signature header" }, 401);

    const { t, te, li } = parseSignatureHeader(sigHeader);
    if (!t) return json({ error: "Invalid signature header (missing t)" }, 401);

    // Use li (live) if present, else te (test)
    const providedSig = (li || te || "").trim();
    if (!providedSig) return json({ error: "Invalid signature header (missing li/te)" }, 401);

    const sigString = `${t}.${rawBody}`;
    const keyBytes = new TextEncoder().encode(PAYMONGO_WEBHOOK_SECRET);
    const msgBytes = new TextEncoder().encode(sigString);

    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      keyBytes,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"],
    );
    const signed = await crypto.subtle.sign("HMAC", cryptoKey, msgBytes);
    const computedSig = toHex(new Uint8Array(signed));

    if (!timingSafeEqual(computedSig, providedSig)) {
      return json({ error: "Invalid signature" }, 401);
    }

    const payload = JSON.parse(rawBody);
    const event = payload?.data;
    const eventType = event?.type || "";

    // Only process successful payments
    if (eventType !== "checkout_session.payment.paid") {
      return json({ received: true, ignored: true });
    }

    const session = event?.data;
    const sessionId = session?.id || "";
    const referenceNumber: string = session?.attributes?.reference_number || "";

    // Reference format: vip:<userId>:<plan>:<ts>
    const parts = referenceNumber.split(":");
    const userId = parts.length >= 4 ? parts[1] : "";
    const plan = (parts.length >= 4 ? parts[2] : "") as Plan;

    if (!userId || !plan) return json({ error: "Missing userId/plan reference_number" }, 400);

    let vip_until: string | null = null;
    const now = new Date();
    if (plan === "monthly") vip_until = addMonths(now, 1).toISOString();
    if (plan === "yearly") vip_until = addMonths(now, 12).toISOString();
    if (plan === "lifetime") vip_until = null;

    const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const { error: updErr } = await adminClient
      .from("profiles")
      .update({
        plan,
        vip_status: "active",
        vip_until,
        payment_status: "paid",
        payment_reference: sessionId ? `${referenceNumber} | ${sessionId}` : referenceNumber,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId);

    if (updErr) return json({ error: "Failed to update profile", details: updErr }, 500);

    return json({ received: true, updated: true });
  } catch (e) {
    console.error(e);
    return json({ error: (e && e.message) ? e.message : "Unknown error" }, 500);
  }
});

