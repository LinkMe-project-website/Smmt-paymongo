# PayMongo VIP Setup (SMMT)

Ito na yung last step: **PayMongo checkout + webhook** para automatic na mag-`VIP active` yung user pagkatapos magbayad.

## 1) PayMongo dashboard (phone friendly)

1. Tapusin muna yung PayMongo onboarding/KYC (yung screen mo na **Business Information**).
2. Pag ok na, punta sa `Developers / API Keys`:
   - copy `sk_test_...` (testing)
   - later `sk_live_...` (live)

## 2) Supabase secrets (Dashboard)

Sa Supabase project mo:

1. `Project Settings → Edge Functions → Secrets`
2. Add these:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `PAYMONGO_SECRET_KEY` (sk_test o sk_live)
   - `PAYMONGO_WEBHOOK_SECRET` (galing sa PayMongo webhook endpoint)
   - `APP_SUCCESS_URL` (example: `https://YOUR-SITE/success.html`)
   - `APP_CANCEL_URL` (example: `https://YOUR-SITE/cancel.html`)
3. Optional:
   - `PAYMONGO_PAYMENT_METHOD_TYPES` (example: `gcash,paymaya,card,qrph`)

## 3) Deploy Supabase Edge Functions

Sa folder na ito, nandito na yung code:

- `supabase/functions/paymongo_create_checkout/index.ts`
- `supabase/functions/paymongo_webhook/index.ts`

**Important:** usually kailangan ng **laptop / Supabase CLI** para mag-deploy ng Edge Functions.

Basic CLI flow (kung may laptop kahit sandali):

1. `supabase login`
2. `supabase link --project-ref <your_project_ref>`
3. `supabase functions deploy paymongo_create_checkout`
4. `supabase functions deploy paymongo_webhook`

Pag deployed na, magkakaroon ka ng URLs na parang:

- `https://<project-ref>.functions.supabase.co/paymongo_create_checkout`
- `https://<project-ref>.functions.supabase.co/paymongo_webhook`

## 4) PayMongo webhook endpoint

Sa PayMongo dashboard:

1. `Developers → Webhooks`
2. `Add endpoint`
3. URL: yung `paymongo_webhook` URL mo sa Supabase
4. Subscribe event: `checkout_session.payment.paid`
5. Copy yung **signing secret** ng endpoint at i-save sa Supabase secret na `PAYMONGO_WEBHOOK_SECRET`

## 5) Frontend (ready na)

Na-update na yung app:

- Sa VIP modal, yung button ay **PayMongo Checkout** na
- Tatawag siya sa Supabase Edge Function `paymongo_create_checkout`
- Then auto-redirect sa `checkout_url`

After payment: PayMongo magre-redirect sa `success.html` / `cancel.html`, then webhook ang mag-aactivate ng VIP sa `profiles`.

## 6) Hosting (free)

Kung gusto mo mabilis at phone-friendly:

1. Create Netlify account
2. `Add new site → Deploy manually`
3. Upload **lahat ng files** ng folder na ito (kasama `index.html`, `script.js`, `style.css`, `success.html`, `cancel.html`)
4. Pag live na, gamitin yung Netlify URL sa `APP_SUCCESS_URL` / `APP_CANCEL_URL`

> Note: kung gusto mo talaga ng sariling `.com` domain, usually **paid** siya. Pero pwede tayo mag-start sa free domain (example `*.netlify.app`) habang testing.

